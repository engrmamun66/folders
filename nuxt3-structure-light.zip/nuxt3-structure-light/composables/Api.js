import axios from 'axios'
function Api(accessToken = true) {
    let options = { baseURL: useRuntimeConfig().public.API_BASE_URL }
    if (accessToken) options['headers'] = { authorization: useCookie('tokenType').value + " " + useCookie('accessToken').value }
    let api = axios.create(options)
    api.interceptors.request.use((config) => {
        authMethods().logoutIfExpireToken()
        return config
    }, (error) => {
        return Promise.reject(error)
    })
    api.interceptors.response.use((response) => {
        return response
    }, (error) => {
        return Promise.reject(error);
    })
    return api
}
export { Api }