<template>
  <div :class="{template_in: useMenuState().value.menu=='guards'}">
    <page-content-header title="Guard Create" :links="[{title:'Guard', href: '/guards'}, {title:'Create', href: ''}]"/>
    <div class="row">
      <imagePreview v-model="show" v-model:imageUrls="imageUrls" />
      <admin-card class="col-lg-12 col-md-12 col-12" title="Create Guard" :showFooter="false" :showPagination="true"
      @admin-card-submit="false/**call function*/" 
      @admin-card-cancel="false/**call function*/" 
      @admin-card-back="back/**call function*/"
      >
          <template  v-slot:before-back-button>
            <nuxt-link @click="sound()" to="/guards/create" class="leap-btn leap-back-btn me-2" type="button"> <i-las t="plus"/> Guard</nuxt-link>
          </template>
          <template  v-slot:after-back-button></template>
          <template  v-slot:card-body>
              <h1>Guard Create</h1>
          </template>
          <template #pagination>
              <!-- <pagination v-model="paginateData" @jumpToPage="jumpPage/**Call function*/" /> -->
          </template>
      </admin-card>

    </div>
  </div>
</template>

<script setup>
definePageMeta({
    middleware: ["auth"],
});

let myValue = ref('Hello')
let myOptions = ref([{id:1, text: 'Hello', id:2, text: 'world'}])

function myChangeEvent(val){
  console.log(val);
}
function mySelectEvent({id, text}){
    console.log({id, text})
}


let show = ref(false)
let imageUrls = ref([])
let isShow = ref(false);

</script>
<style scoped>
table tr td img{
  border-radius: 4px;
}
</style>
