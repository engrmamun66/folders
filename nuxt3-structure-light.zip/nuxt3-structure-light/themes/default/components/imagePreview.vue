<template>
  <teleport v-if="modelValue" to="body">
    <div class="image-previewer">
      <div style="display:none">
        <img v-for="(url, i) in imageUrls" :key="i" :src="url" alt="">
      </div>
      <div
        @click="$emit('update:modelValue', false)"
        @wheel="zoomInOut"
        class="image-container"
      >
        <img
          ref="_img"
          @click="$event.stopPropagation()"
          @touchstart="slideImageByTouch"
          @touchmove="slideImageByTouch"
          @touchend="slideImageByTouch"
          :src="url"
          :class="{
            [getChangingClass]: changingImage,
            [getChangedClass]: changedImage,
          }"
          alt=""
          :style="'transition: all 0.3s;scale:' + scale + ';' + (movingTouch ? getMovingStyles : '')"
        />
        <p class="image-name text-white-50"> {{ url ? getExcerpt(decodeURI(url).split('/').at(-1), 36) : '' }} </p>
      </div>
      <div v-if="imageUrls.length > 1" class="prev-next-area">
        <span
          class="btn-prev-next btn-prev"
          @click="prev"
          :style="index > 0 ? 'opacity:1' : 'opacity:0.5;'"
        >
          <i-las t="angle-left" />
        </span>
        <span
          class="btn-prev-next btn-next"
          @click="next"
          :style="imageUrls.length - 1 > index ? 'opacity:1' : 'opacity:0.5'"
        >
          <i-las t="angle-right" />
        </span>
      </div>
    </div>
  </teleport>
</template>

<script setup>
let props = defineProps({ 
  modelValue: {
    type: Boolean,
    default: false,
    required: true,
  },
  imageUrls: {
    type: Array,
    required: true,
  }, 
  index:{
    type:Number, 
    default: 0
  } 
});
let commonState = useCommonState("common");
let scale = ref(1);
function zoomInOut(event){
  if (event.deltaY < 0){
    if(scale.value > .4) scale.value -= .4;
  }
  else if (event.deltaY > 0)
  {
    scale.value += 0.4;
  }
}

let url = computed(() => {
  if (props.index > -1 && props.index <= props.imageUrls.length - 1) {
    return props.imageUrls[props.index];
  }
});

let changingImage = ref(false);
let changedImage = ref(true);
let movingTouch = ref(false);

let getChangingClass = ref('changing-image')
let getChangedClass = ref('changed-image')
let getMovingStyles = ref('touch-moving')

function next(event = false) {
  if (event) event.stopPropagation();
  if (props.index <= props.imageUrls.length - 2) {
    getChangingClass.value = 'changing-image-next'
    getChangedClass.value = 'changed-image-next'
    changingImage.value = true;
    changedImage.value = false;
    scale.value = 1
    setTimeout(() => {
      myEmit('update:index', props.index + 1)
      changingImage.value = false;
      changedImage.value = true;
    }, 400);
  }
}
function prev(event = false) {
  if (event) event.stopPropagation();
  if (props.index > 0) {
    getChangingClass.value = 'changing-image-prev'
    getChangedClass.value = 'changed-image-prev'
    changingImage.value = true;
    changedImage.value = false;
    scale.value = 1
    setTimeout(() => {
      myEmit('update:index', props.index - 1)
      changingImage.value = false;
      changedImage.value = true;
    }, 400);
  }
}
onMounted(() => {
  let imgPrev = document.querySelector(".image-previewer");
  document.removeEventListener("keydown", imgPrev);
  document.addEventListener("keydown", (event) => {
    if (event.code == "ArrowLeft") prev();
    if (event.code == "ArrowRight") next();
    if (event.code == "NumpadAdd" || event.code == "Equal") scale.value += 0.2;
    if (event.code == "NumpadSubtract" || event.code == "Minus")
      scale.value > 0.4 ? (scale.value -= 0.2) : "";
    if (event.code == "Numpad0" || event.code == "Digit0") scale.value = 1;
  });
});
const clientX_start = ref(0)
const clientX_end = ref(0)
const translateX = ref(0)
function slideImageByTouch(event) {
    if (event.type == 'touchstart')
      clientX_start.value = event.changedTouches[0].clientX

    if (event.type == 'touchend') {
      movingTouch.value = false
      getMovingStyles.value = 'opacity:1;translateX(0px)'
      translateX.value = 0

      clientX_end.value = event.changedTouches[0].clientX
        let movedPixel = clientX_end.value - clientX_start.value
        if (clientX_end.value > clientX_start.value && movedPixel >= 50) prev()
        else if (clientX_end.value < clientX_start.value && movedPixel <= 50) next()
    }
    if (event.type == 'touchmove'){
      movingTouch.value = true
      let currentX = event.changedTouches[0].clientX
      let opacity = '0.5'
      let step = 1
      // For Next
      if(clientX_start.value < currentX){
        translateX.value += step 
        getMovingStyles.value = `opacity:${opacity};transform: translateX(${translateX.value}px);`
      }
      // For Prev
      if(clientX_start.value > currentX){
        translateX.value -= step
        getMovingStyles.value = `opacity:${opacity};transform: translateX(${translateX.value}px);`
      } 
    }
}
let getExcerpt = (text, maxlen=20) => {
  if(text.length > maxlen){
    let slap = Math.floor(maxlen / 2)
    return Array.from(text).slice(0, slap).join('') + '....' + Array.from(text).slice(-(slap)).join('')
  }else{
    return text
  }
}
let myEmit = defineEmits(['update:modelValue', 'update:index'])

</script>

<style scoped>
.image-previewer {
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background-color: rgba(0, 0, 0, 0.664);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(5);
  z-index: 99;
}
.image-previewer .prev-next-area {
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  pointer-events: none;
}
.image-previewer .prev-next-area .btn-prev-next {
  display: flex;
  background-color: #7a6e6e33;
  align-items: center;
}
.image-previewer .prev-next-area .btn-prev {
  justify-content: flex-start;
  border-left: none;
  pointer-events: all;
}
.image-previewer .prev-next-area .btn-next {
  justify-content: flex-end;
  border-right: none;
  pointer-events: all;
}

:global(.image-previewer .prev-next-area i) {
  font-size: 3rem;
  cursor: pointer;
  padding: 55px 40px;
  color: var(--fontcolor-primary);
}
.image-previewer .image-container {
  width: 100%;
  height: 100vh;
  display: flex;
  flex-flow: column;
  align-items: center
}
.image-previewer img {
  object-fit: contain;
  margin: auto;
  border-radius: 3px;
}
/* -------------------------------------------------------------------------- */
/*                                Desktop size                                */
/* -------------------------------------------------------------------------- */
@media only screen and (min-width: 701px) {
  .image-previewer img {
    height: 300px;
    width: auto;
  }
  .image-name{
    transform: translateY(-5rem);
  }
}
/* -------------------------------------------------------------------------- */
/*                                 Mobile Size                                */
/* -------------------------------------------------------------------------- */
@media only screen and (max-width: 700px) {
  .image-previewer img {
    width: calc(100% - 40px);
    height: auto;
  }
  .image-previewer .prev-next-area {
    align-items: flex-end;
  }
  .image-name{
    padding-bottom: 5rem !important;
    text-align:left;
  }
  .image-previewer .prev-next-area .btn-prev-next {
    width: 50%;
    padding: 20px;
  }
  :global(.image-previewer .prev-next-area .btn-prev-next:first-child){
    width: 50%;
    padding: 20px;
    border-right: 1px solid black !important;
  }
  :global(.image-previewer .prev-next-area .btn-prev-next i) {
    text-align: center;
    font-size: 2rem;
    color: white;
    padding: 0;
  }
}
/* -------------------------------------------------------------------------- */
/*                              Animation For Next                             */
/* -------------------------------------------------------------------------- */
.changing-image-next {
  display: block;
  opacity: 0;
  animation-name: changing-image-next;
  animation-duration: 0.3s;
  animation-iteration-count: 1;
}
@keyframes changing-image-next {
  from {
    opacity: 1;
    transform: translateX(0rem);
    scale: 1;
  }
  to {
    opacity: 0;
    transform: translateX(-25rem);
    scale: 1;
  }
}
.changed-image-next {
  display: block;
  animation-name: changed-image-next;
  animation-duration: 0.3s;
  animation-iteration-count: 1;
}
@keyframes changed-image-next {
  from {
    opacity: 1;
    transform: translateX(25rem);
    scale: 1;
  }
  to {
    opacity: 1;
    transform: translateX(0rem);
    scale: 1;
  }
}
/* -------------------------------------------------------------------------- */
/*                              Animation For Prev                             */
/* -------------------------------------------------------------------------- */
.changing-image-prev {
  display: block;
  opacity: 0;
  animation-name: changing-image-prev;
  animation-duration: 0.3s;
  animation-iteration-count: 1;
}
@keyframes changing-image-prev {
  from {
    opacity: 1;
    transform: translateX(0rem);
    scale: 1;
  }
  to {
    opacity: 0;
    transform: translateX(25rem);
    scale: 1;
  }
}
.changed-image-prev {
  display: block;
  animation-name: changed-image-prev;
  animation-duration: 0.3s;
  animation-iteration-count: 1;
}
@keyframes changed-image-prev {
  from {
    opacity: 1;
    transform: translateX(-25rem);
    scale: 1;
  }
  to {
    opacity: 1;
    transform: translateX(0rem);
    scale: 1;
  }
}
</style>