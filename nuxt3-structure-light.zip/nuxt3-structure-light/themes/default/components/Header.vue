<template>
  <nav class="navbar navbar-expand-lg navbar-light" :class="{margin_left : menuMethods('isCollapse')}">
    <div class="container-fluid fullheight-100">
      <div class="navbar-middle fullheight-100">
        <div class="leap-admin-header-logo-responsive">
          <div class="logo-area-inner">
            <div class="logo-area-middle">
              <nuxt-link to="/">
                <img src="/img/logo-white.webp" @dblclick="useCookie('useSound').value = !useCookie('useSound').value" />
              </nuxt-link>
            </div>
          </div>
        </div>
        <div class="leap-admin-headermenu-responsive">
          <ul>
            <li>
                <a style="line-height:30px" class="selected" @click.prevent="authState.loading_insptd= !authState.loading_insptd"><i-las t="sign-in" /> <BtnLoader :show="authState.loading_insptd" /></a>
            </li>
            <li>
              <a class="leap-admin-sidebarCollapse" @click="menuMethods('toggleSidebar')"
                ><i-las t="bars" /></a>
            </li>
            <li style="display:none">
              <a class="header-menu"><i class="la la-menu"></i></a>
            </li>
            <li>
              <a class="header-user pe-0" @click="menuMethods('toggleProfilePopup')"><img class="profile-img" v-if="authState.user?.profile_img"  :src="authState.user?.profile_img"> <i v-else class="la la-user"></i></a>
              <div @mouseleave="useMenuState('menu').value.showProfilePopup=false;sound('pop-out')" class="leap-admin-rightside-dropdown --animate-show" :class="{selected: useMenuState('menu').value.showProfilePopup}"
                  :style="useMenuState('menu').value.showProfilePopup ? 'display:block' : '' ">
                  <div>
                    <div class="leap-admin-rightside-topbar text-left">
                      <h4 class="flex-center w-100 ps-4">
                        <span class="text-white">{{ authState.user ? authState.user.name : '' }}</span>
                        <span class="usermail">{{ authState.user ? authState.user.email : '' }}</span>
                      </h4>
                    </div>
                    <div class="leap-admin-rightside-body">
                      <ul class="leap-admin-userprofile-menu">
                        <li><a><i class="lni lni-user"></i> My Profile</a></li>
                        <li> <a><i class="lni lni-laptop"></i> My Task</a></li>
                        <li class="mt-2">
                          <a class="logout-btn" @click="authState.loading=true;authMethods('logout')">
                            <i class="fa fa-sign-out"></i> Logout <BtnLoader :show="authState.loading" />
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
            </li>
          </ul>
        </div>
        <div class="navbar-left-side">
          <nav class="leftside-top-nav">
            <ul class="leftside-navmenu d-flex justify-content-between">
                <div class="d-flex justify-content-start">
                  <li class="pt-3">
                      <el-BaseSelect style="min-width: 200px;" v-model="qData.company_id" option1="-Company-" :charLimit="24"
                      :data="[{id:1, name: 'Test'}]" valueKey="id" displayKey="name" />
                  </li>
                  <li class="pt-3">
                      <el-BaseSelect style="min-width: 200px;" v-model="qData.site_id"  option1="-Site-" :charLimit="24"
                      :data="[{id:1, name: 'Test'}]" valueKey="id" displayKey="title"/>
                  </li>
                  <li class="pt-3">
                    <el-BaseInput type="search" v-model="qData.guard" @blur="false" placeholder="Find Guard" tooltip="Type guard by name" flow="down"/>
                  </li>
                </div>
            </ul>
          </nav>
        </div>
        <div class="navbar-right-side" :style="useMenuState('menu').value.showRighttSideNavbar ? 'display:block' : '' ">
          <nav class="rightside-top-nav">
            <ul class="rightside-navmenu"> 
              <li>
                <div>
                  <div class="btn-actions-toggler">
                    <button @click="useCommonState().value.headerActions = !useCommonState().value.headerActions;sound(useCommonState().value.headerActions ? 'pop' : 'pop-out')" 
                    class="leap-btn leap-back-btn padding-as-input">Actions <i-las t="down-arrow" class="ps-1" fontSize="12px" /></button>
                    <ul @mouseleave="useCommonState().value.headerActions = false;sound('pop-out')" class="action-box py-2" :class="{'--animate-show': useCommonState().value.headerActions, '--animate-hide': !useCommonState().value.headerActions}">
                      <li @click.prevent="authState.loading_insptd=!authState.loading_insptd"> <a> <i t="sign-in" class="size-fw" /> InspectDeploy <BtnLoader :show="authState.loading_insptd" /></a> </li>
                    </ul>
                  </div>
                </div>
              </li>

              <li class="leap-admin-right-dropdown">
                <a class="leap-admin-dropdown-link" @click="menuMethods('toggleProfilePopup');sound('pop')"
                  ><img  class="profile-img" v-if="authState.user?.profile_img"  :src="authState.user.profile_img"> <i v-else class="la la-user"></i> </a>
                <ul @mouseleave="useMenuState('menu').value.showProfilePopup=false;sound('pop-out')" class="leap-admin-rightside-dropdown --animate-show" :class="{selected: useMenuState('menu').value.showProfilePopup}"
                  :style="useMenuState('menu').value.showProfilePopup ? 'display:block' : '' ">
                  <li>
                    <div class="leap-admin-rightside-topbar text-left">
                      <h4 class="flex-center w-100 ps-4">
                        <span class="text-white">{{ authState.user ? authState.user.name : '' }}</span>
                        <span class="usermail">{{ authState.user ? authState.user.email : '' }}</span>
                      </h4>
                    </div>
                    <div class="leap-admin-rightside-body">
                      <ul class="leap-admin-userprofile-menu">
                        <li>
                          <a>
                            <i class="lni lni-user"></i> My Profile
                          </a>
                        </li>
                        <li>
                          <a>
                            <i class="lni lni-laptop"></i> My Task
                          </a>
                        </li>
                        <li class="mt-2">
                          <a class="logout-btn" @click="authState.loading=true;authMethods('logout')">
                            <i class="fa fa-sign-out"></i> Logout <BtnLoader :show="authState.loading" />
                          </a>
                        </li>
                      </ul>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </nav>
</template>
<script setup>
let authState = useAuthState("auth");
let qData = ref({
  company_id: null,
  site_id: null,
  guard: null,
});

function findGuards() {
  if (qData.value.company_id || qData.value.site_id || qData.value.guard) {
    sound()
    useRouter().push({ path: "/guards", query: cloneDeep(qData.value) });
    setTimeout(() => {
      if (document.getElementById("REFRESH-GUARDS"))
        document.getElementById("REFRESH-GUARDS").click();
    }, 200);
  }
}
</script>