<template>
  <div v-bind="$attrs">
    <div class="leap-admin-content-wrapper">
      <div class="leap-admin-card">
        <div v-if="showHeader" class="m-portlet__head">
          <div class="m-portlet__head-caption">
            <div class="m-portlet__head-title">
              <h3 class="m-portlet__head-text"> {{ title }} </h3>
              <div class="leap-admin-title-rightcontent-side">
                <div v-if="headerButtons" class="leap-admin-title-rightcontent-side-inner">
                  <slot name="before-back-button"></slot>
                  <button @click="$emit('admin-card-back')" class="leap-btn leap-back-btn" type="button">Back</button>
                  <slot name="after-back-button"></slot>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div v-if="showBody" class="leap-admin-card-body">
          <slot name="card-body"></slot>
        </div>
        <div v-if="showFooter" class="card-footer">
          <button v-if="mode=='create'" type="button" class="leap-btn leap-submit-btn me-2" @click="submit" :disabled="isCalling?.adding"> {{ submitText }} <btn-loader :show="isCalling?.adding" color="'white'" />  </button>
          <button v-if="mode=='update'" type="button" class="leap-btn leap-submit-btn me-2" @click="update" :disabled="isCalling?.updating"> Update <btn-loader :show="isCalling?.updating" color="'white'" /></button>
          <button type="reset" class="leap-btn leap-cancel-btn" @click="cancel"> {{ cancelText }} </button>
        </div>
        <div v-if="showPagination" class="d-flex justify-content-center mb-2">
          <!-- Pagination -->
          <slot name="pagination"></slot>
        </div>
      </div>
  </div>
  </div>
</template>

<script setup>
let props = defineProps({
    title:{
        type: String, 
        default:'.........',
        required: true,
    },
    submitText: {
      type: String,
      default: 'Submit',
      required: false,
    },
    cancelText: {
      type: String,
      default: 'Cancel',
      required: false,
    },
    mode: {
      type: String,
      default: 'create', // create | update
      required: false,
    },
    showHeader: {
      type: Boolean,
      default: true,
      required: false,
    },
    headerButtons: {
      type: Boolean,
      default: false,
      required: false,
    },
    showBody: {
      type: Boolean,
      default: true,
      required: false,
    },
    showFooter: {
      type: Boolean,
      default: true,
      required: false,
    },
    showPagination: {
      type: Boolean,
      default: false,
      required: false,
    },
    isCalling: {
      type: Object,
      default: {},
      required: false,
    },
})

let emit = defineEmits(['admin-card-submit', 'admin-card-update', 'admin-card-cancel', 'admin-card-back'])
let submit = (event) => {
  emit('admin-card-submit')
}
let cancel = (event) => {
  emit('admin-card-cancel')
}
let update = (event) => {
  emit('admin-card-update')
}

</script>
