<template>
  <nav id="leap-admin-sidebar" class="leap-admin-sidebar" :class="{active : !menuMethods('isCollapse')}">
    <div class="sidebar-header">
      <div class="logo-area-inner">
        <div class="logo-area-middle">
          <nuxt-link to="/">
            <img src="/img/logo-white.webp" @dblclick="useCookie('useSound').value = !useCookie('useSound').value"/>
          </nuxt-link>
        </div>
        <div class="leap-admin-collapes-area">
          <a class="leap-admin-sidebarCollapse">
            <span class="sidebar-leftmenu-icon" @click="menuMethods('toggleSidebar');sound('pop')" :tooltip="menuMethods('isCollapse') ? 'Expand' : 'Collaps'" flow="right">
              <i-las t="left-arrow" />
              <i-las t="left-arrow" />
            </span>
            <span class="sidebar-rightmenu-icon" @click="menuMethods('toggleSidebar');sound('pop')" :tooltip="menuMethods('isCollapse') ? 'Expand' : 'Collaps'" flow="right">
                <i-las t="right-arrow" />
                <i-las t="right-arrow" />
            </span>
          </a>
        </div>
      </div>
    </div>

    <ul id="leap-admin-accordion" class="leap-admin-accordion">
      <li>
        <nuxt-link @click="sound();menuMethods('activeMenu', 'dashboard')" to="/" class="leftsidebar-link menu-tooltip" :class="{'active': menuMethods('isCurrent', 'dashboard')}" >
          <i-las t="home" />
          <span class="menu-text">Dashboard</span>
          <span class="tooltip__text tooltip__text--right"> Dashboard </span>
        </nuxt-link>
      </li>
       <li @click="sound();menuMethods('activeSubMenu', 'report', 'list')">
          <nuxt-link to="/report"   class="collaps-togglelink menu-tooltip"  :class="{'active': menuMethods('isCurrent', 'report','list')}">
            <i-las t="map-pin" /><span class="menu-text">report</span>
            <span class="tooltip__text tooltip__text--right"> report </span>
          </nuxt-link>
        </li>
      <li>
          <a @click="sound();menuMethods('activeMenu', 'guards')" 
            class="collaps-togglelink menu-tooltip" :class="{active: menuMethods('isCurrent', 'guards')}">
            <i-las t="male" /><span class="menu-text">Guards</span>
            <span class="menu-plusminus-icon"><i class="lni" :class="[menuState.isCollapseMenu && menuState.menu == 'guards' ? 'lni-chevron-down' : 'lni-chevron-right']"></i></span>
            <span class="tooltip__text tooltip__text--right"> Guards </span>
          </a>
          <ul class="accord-submenu" :class="{'--animate-show':menuMethods('isCurrent', 'guards')}" :style="menuMethods('isCurrent', 'guards') ? 'display: block' : ''">
            <li @click="sound();menuMethods('activeSubMenu', 'guards', 'list')">
              <nuxt-link to="/guards" class="leftsidebar-link" :class="{'active': menuMethods('isCurrent', 'guards', 'list')}">
                <i-las t="list" />
                <span class="menu-text">All Guards</span>
                <span class="tooltip__text tooltip__text--right"> > All Guards </span>
              </nuxt-link>
            </li>
          </ul>
      </li>
      
    </ul>
  </nav>
</template>
<script setup>
  let menuState = useMenuState()
</script>
<style scoped>
  .router-link-active[data-v-b58d64c7] {
    background: #2d4038 !important;
}
</style>