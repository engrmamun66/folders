<template>
  <div>
    <page-content-header title="Dashboard" :links="false" />
    <div class="row">
    </div>
</div>
 

</template>

<script setup>
definePageMeta({
  middleware: ["auth"],
})



</script>