<template>
    <div :class="{template_in: useMenuState().value.menu=='reports'}">
      <page-content-header title="Reports" :links="false" />
      <div class="row">
        <admin-card class="col-lg-12 col-md-12 col-12" title="Reports"
          @admin-card-submit="false/**call function*/" 
          @admin-card-cancel="false/**call function*/" 
          @admin-card-back="false/**call function*/"
          >
            <template  v-slot:before-back-button> </template>
            <template  v-slot:after-back-button> </template>
            <template  v-slot:card-body>
                <h1>Body content</h1>
            </template>
          </admin-card>
      </div>
  </div>
</template>