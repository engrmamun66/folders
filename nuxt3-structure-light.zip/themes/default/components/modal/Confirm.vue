<template>
  <!-- Vertically centered modal -->
  <teleport to="body">
    <div
      class="modal fade "
      :class="{ show: modelValue }"
      :style="modelValue ? 'display: block' : 'display: none'"
    >
      <div class="modal-dialog" :class="[top ? '' : 'modal-dialog-centered']">
        <div @click="sound('pop-out');$event.stopPropagation()" class="modal-content">
          <div class="modal-header">
              <h6 class="modal-title" id="exampleModalCenterTitle"> {{ title }} </h6>
              <button @click="sound('pop-out');close()" type="button" class="btn-close" aria-label="Close"><i class="la la-close"></i></button>
          </div>
          <div class="modal-body d-flex justify-content-center">
              <button @click="sound('pop-out');yes()" type="button" class="leap-btn leap-submit-btn px-4 me-3">Yes</button>
              <button @click="sound('pop-out');no()" type="button" class="leap-btn leap-cancel-btn px-4 ">No</button>
          </div>
        </div>
      </div>
    </div>
  </teleport>
</template>

<script setup>
defineProps({
  modelValue: {
        type: Boolean,
        default: false,
        required: true
  },
  title: {
    type: String,
    default: 'Are you confirm ?',
    required: false,
  },
  top: {
    type: Boolean,
    default: false,
    required: false,
  },
});
let emit = defineEmits(['update:modelValue', 'clicked-yes', 'clicked-no', 'clicked-close'])
let yes = (event) => {
  emit('clicked-yes')
  emit('update:modelValue', false)
}
let no = (event) => {
  emit('clicked-no')
  emit('update:modelValue', false)
}
let close = (event) => {
  emit('clicked-close')
  emit('update:modelValue', false)
}

</script>

<style scoped>
.modal {
  background-color: rgb(0 0 0 / 59%);
}
.modal-dialog {
  width: 360px;
}
.modal.show .modal-content{
    animation: mymove 0.3s;
}
@keyframes mymove {
  from {transform: translateY(-100px); opacity: 0; scale: 0.5;}
  to {transform: translateY(0px); opacity: 1; scale: 1}
}
</style>