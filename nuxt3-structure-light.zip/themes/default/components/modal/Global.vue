<template>
  <!-- Vertically centered modal -->
  <div
    class="modal fade"
    :class="{ show: modelValue }"
    :style="modelValue ? 'display: block' : 'display: none'"
    @click="sound('pop-out');$emit('update:modelValue', false)"
  >
    <div 
      class="modal-dialog modal-dialog-scrollable"
      :class="[top ? '' : 'modal-dialog-centered']"
    >
      <div @click="$event.stopPropagation()" class="modal-content">
        <div class="modal-header">
          <h6 class="modal-title" id="exampleModalCenterTitle"> {{ title }} </h6>
          <button @click="sound('pop-out');close()" type="button" class="btn-close" aria-label="Close"><i class="la la-close"></i></button>
        </div>
        <div class="modal-body d-flex justify-content-center">
          <slot name="modalbody" />
        </div>
        <div v-if="footer" class="modal-footer">
            <button @click="sound('pop-out');cancel();$emit('update:modelValue', false)" type="button" class="leap-btn leap-cancel-btn me-2"> {{ cancelText }} </button>
            <button @click="submit" type="button" class="leap-btn leap-submit-btn"> {{ submitText }} <btn-loader :show="isCalling?.adding" color="'white'" /> </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  modelValue: {
    type: Boolean,
    default: false,
    required: true,
  },
  title: {
    type: String,
    default: "Modal",
    required: false,
  },
  top: {
    type: Boolean,
    default: false,
    required: false,
  },
  footer: {
    type: Boolean,
    default: true,
    required: false,
  },
  submitText: {
    type: String,
    default: 'Submit',
    required: false,
  },
  cancelText: {
    type: String,
    default: 'Cancel',
    required: false,
  },
  isCalling: {
    type: Object,
    default: {},
    required: false,
    },
});
let emit = defineEmits(['update:modelValue', 'clicked-submit', 'clicked-cancel', 'clicked-close'])
let submit = (event) => {
  emit('clicked-submit')
}
let cancel = (event) => {
  emit('clicked-cancel')
  emit('update:modelValue', false)
}
let close = (event) => {
  emit('clicked-close')
  emit('update:modelValue', false)
}
</script>

<style scoped>
.modal {
  background-color: rgb(0 0 0 / 59%);
}
.modal.show .modal-content {
  animation: mymove 0.3s;
}
@keyframes mymove {
  from {
    top: -100px;
    opacity: 0;
    scale: 0.5;
  }
  to {
    top: 0px;
    opacity: 1;
    scale: 1;
  }
}
</style>