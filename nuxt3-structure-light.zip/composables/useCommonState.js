import moment from "moment";

function Common(functionName = '', ...args) {
    const methods = {
        toaster(type, message='') {
            let CS = useCommonState().value
            var message = { message: message, type: type, time: new Date().getTime() / 1000 }
            CS.messages.push(message)
            setTimeout(() => {
                CS.messages.forEach((item, index) => {
                    if (item.time == message.time) {
                        CS.messages.splice(index, 1)
                    }
                });
            }, 3000);
        },
        closeToaster(index) {
            useCommonState().value.messages.splice(index, 1)
        },
        autoToaster(response, succes_sound = 'success', toaster = true){
            if (response.status == 200){
                if (response.data.status == 'success' && response.data.data && toaster){
                    if (typeof response.data.data == 'string'){
                        Common().toaster('success', response.data.data)
                        sound(succes_sound, 3000)
                    }
                    if (typeof response.data.data == 'object') {
                        response.data.data.forEach(msg => {
                            Common().toaster('success', msg)
                            sound(succes_sound, 3000)
                        })
                    }
                }
                else if (response.data.status == 'error' && response.data.message){
                    if (typeof response.data.message == 'string'){
                        Common().toaster('warning', response.data.message)
                        sound('error')
                    }
                    if (typeof response.data.message == 'object'){
                        response.data.message.forEach(msg => {
                            Common().toaster('warning', msg)
                            sound('error')
                        })
                    }
                }
            }
            return response.status == 200 && response.data.status == 'success'
        },
        formatDate(date, format = 'YYYY-MM-DD'){
            if (date) return moment(date).format(format);
        },
        /* -------------------------------------------------------------------------- */
        /*                               Modal Function                               */
        /* -------------------------------------------------------------------------- */
        useMixin(mixin) {
            if (mixin && !useNuxtApp().vueApp._context.mixins.includes(mixin)) {
                useNuxtApp().vueApp._context.mixins = useNuxtApp().vueApp._context.mixins.slice(0, 1)
                useNuxtApp().vueApp.mixin(mixin)
            }
        },
    };

    // ===============================
    // ====Dynamic Method call=======
    // ===============================
    if (functionName && methods.hasOwnProperty(functionName)) {
        return methods[functionName](...args)
    } else {
        return methods
    }
}

function formatBytes(bytes, roundType='' /**ceil/floor */, middle=false) {
    if (bytes == 0) {
        return '0 bytes';
    }
    let decimal = 2;
    let k = 1000;
    let dm = decimal + 1 || 3;
    let sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    let i = Math.floor(Math.log(bytes) / Math.log(k));
    let result = parseFloat((bytes / Math.pow(k, i)).toFixed(dm))
    if (['ceil', 'floor'].includes(roundType) && roundType) 
        result = Math[roundType](result)
    return result + middle + sizes[i];
}

let LOCAL = Intl.DateTimeFormat().resolvedOptions().locale
let TIMEZONE = Intl.DateTimeFormat().resolvedOptions().timeZone
async function playSound(sound = 'click', time = 500, delay = 0) {
    if (!useCookie('useSound').value) return
    var audioNode = document.createElement("audio");
    if (sound == 'drop')  audioNode.setAttribute('src', '/sound/drop.mp3')
    if (sound == 'error')  audioNode.setAttribute('src', '/sound/error.mp3')
    if (sound == 'pop') audioNode.setAttribute('src', '/sound/pop.mp3')
    if (sound == 'pop-out') audioNode.setAttribute('src', '/sound/pop-out.mp3')
    if (sound == 'click')  audioNode.setAttribute('src', '/sound/click.mp3')
    if (sound == 'success')  audioNode.setAttribute('src', '/sound/success.mp3')
    if (sound == 'opening')  audioNode.setAttribute('src', '/sound/opening.mp3')
    if (sound == 'back')  audioNode.setAttribute('src', '/sound/back.mp3')
    if (sound == 'switch')  audioNode.setAttribute('src', '/sound/switch.mp3')
    document.getElementsByTagName('body')[0].appendChild(audioNode);
    if (['back'].includes(sound)) audioNode.volume = 0.4; 
    else audioNode.volume = 0.4;
    try {
        setTimeout(() => {
            audioNode.play();
        }, delay);
    } catch (error) {}
    setTimeout(() => {
        document.getElementsByTagName('body')[0].removeChild(audioNode)
    }, (delay + time));
}
function cloneDeep(data) {
    return  JSON.parse(JSON.stringify(data))
}
function randBetween (min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min)
}
let s3 = 'https://s3.us-west-2.amazonaws.com/storage.video.inspect.deploy.io/'
export { Common, s3, formatBytes, LOCAL, TIMEZONE, playSound as sound, cloneDeep, randBetween }; // We can call this function globally

export default function () {
    return useState('common', () => ({
        messages: [],
        headerActions: false,
        zoom: 14,
        queryData :{
            company_id: null,
            site_id: null,
            guard: null,
        }
    }))
}

